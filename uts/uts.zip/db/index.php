<?php
$hostname = 'localhost';
$username = 'v3421098';
$password = '0z8qPLyeXc5T';
$dbname = 'v3421098_lv388';

$conn = mysqli_connect($hostname, $username, $password, $dbname) or die('Gagal terhubung ke database');
